<header id="header" class="-top bg-dark">
    <div class="container d-flex align-items-center">
    <nav id="navbar" class="navbar">
        <ul class="nav">
            <li class="nav-item"><span class="nav-link p-0 text-white me-3">Modalità amministratore</span></li>
            <li class="nav-item"><a class="nav-link p-0 text-white" href="/admin-dash"><i class="bi bi-gear"></i> Panello di controllo</a></li>
        </ul>
    </nav>
    </div>
</header>